package com.salah.blocker

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

object Scheduler {
    // يبدأ الحجب بعد الأذان بثلاث دقائق لكل صلاة.
    const val ADHAN_DELAY_MINUTES = 3L

    data class Win(val idx: Int, val start: ZonedDateTime, val end: ZonedDateTime)

    fun windows(ctx: Context): List<Win> {
        val p = Prefs(ctx)
        val z = ZoneId.systemDefault()
        val today = LocalDate.now(z)
        val out = mutableListOf<Win>()
        for (d in -1L..2L) {
            val date = today.plusDays(d)
            val ts = PrayerRepo.timesFor(ctx, date) ?: continue
            ts.forEachIndexed { i, t ->
                val adhan = date.atTime(t).atZone(z)
                val s = adhan.plusMinutes(ADHAN_DELAY_MINUTES)
                out += Win(i, s, s.plusMinutes(p.duration.toLong()))
            }
        }
        return out.sortedBy { it.start.toInstant().toEpochMilli() }
    }

    fun current(ctx: Context): Win? {
        if (!Prefs(ctx).enabled) return null
        val n = ZonedDateTime.now()
        return windows(ctx).firstOrNull { !n.isBefore(it.start) && n.isBefore(it.end) }
    }

    fun isBlocking(ctx: Context) = current(ctx) != null

    fun next(ctx: Context): Win? {
        val n = ZonedDateTime.now()
        return windows(ctx).firstOrNull { it.start.isAfter(n) }
    }

    private fun pending(ctx: Context) = PendingIntent.getBroadcast(
        ctx, 1, Intent(ctx, AlarmReceiver::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    /** يضبط منبهًا واحدًا لأقرب حدث (بداية/نهاية حجب) أو لتحديث منتصف الليل. */
    fun reschedule(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = pending(ctx)
        am.cancel(pi)
        if (!Prefs(ctx).enabled) return
        val now = ZonedDateTime.now()
        val nowMs = now.toInstant().toEpochMilli()
        val boundary = windows(ctx).flatMap { listOf(it.start, it.end) }
            .map { it.toInstant().toEpochMilli() }.filter { it > nowMs }.minOrNull()
        val midnight = now.toLocalDate().plusDays(1).atTime(0, 10).atZone(now.zone).toInstant().toEpochMilli()
        val retry = nowMs + 3_600_000L
        val at = minOf(boundary ?: retry, midnight)
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        else
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
    }

    fun ensureVpn(ctx: Context) {
        try {
            if (Prefs(ctx).enabled && VpnService.prepare(ctx) == null)
                ctx.startForegroundService(Intent(ctx, DnsVpnService::class.java))
        } catch (e: Exception) { }
    }

    /** يُستدعى من المنبه ومن الإقلاع: يجدول فورًا ثم يحدّث المواقيت. */
    fun tick(ctx: Context) {
        reschedule(ctx)
        BlockerService.instance?.checkNow()
        ensureVpn(ctx)
        PrayerRepo.ensure(ctx)
        reschedule(ctx)
    }
}
