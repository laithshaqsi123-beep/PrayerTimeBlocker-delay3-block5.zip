package com.salah.blocker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors

/**
 * نموذج أولي لـ VPN محلي يعالج استعلامات DNS عبر IPv4/UDP فقط.
 * لا يضمن حجب DNS عبر TCP أو IPv6 أو DNS-over-HTTPS/Private DNS؛ لذلك لا يجوز وصفه
 * بأنه حجب شامل لكل المواقع قبل استبداله بمكدس VPN/DNS مكتمل واختباره.
 */
class DnsVpnService : VpnService() {
    @Volatile private var running = false
    private var tun: ParcelFileDescriptor? = null
    private val pool = Executors.newCachedThreadPool()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vpn", "حجب المواقع", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "vpn")
            .setContentTitle("صلاة – وقت العبادة")
            .setContentText("خدمة حجب المواقع تعمل")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock).build()
        startForeground(1, n)
        if (!running) start()
        return START_STICKY
    }

    private fun start() {
        val t = Builder().setSession("صلاة")
            .addAddress("10.111.222.1", 24)
            .addDnsServer("10.111.222.2")
            .addRoute("10.111.222.2", 32)
            .establish() ?: return
        tun = t
        running = true
        Thread {
            val inp = FileInputStream(t.fileDescriptor)
            val out = FileOutputStream(t.fileDescriptor)
            val buf = ByteArray(32767)
            try {
                while (running) {
                    val n = inp.read(buf)
                    if (n > 0) handle(buf, n, out)
                }
            } catch (e: Exception) { }
        }.start()
    }

    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)

    private fun handle(pkt: ByteArray, n: Int, out: FileOutputStream) {
        if (n < 28 || (pkt[0].toInt() shr 4) != 4 || pkt[9].toInt() != 17) return
        val ihl = (pkt[0].toInt() and 15) * 4
        if (n < ihl + 8 || u16(pkt, ihl + 2) != 53) return
        val sport = u16(pkt, ihl)
        val dns = pkt.copyOfRange(ihl + 8, n)
        val src = pkt.copyOfRange(12, 16)
        val dst = pkt.copyOfRange(16, 20)
        pool.execute {
            try {
                val name = qname(dns)
                val resp = if (name != null && isBlocked(name)) nxdomain(dns) else forward(dns)
                if (resp != null) write(out, dst, src, 53, sport, resp)
            } catch (e: Exception) { }
        }
    }

    private fun qname(d: ByteArray): String? {
        var pos = 12
        val sb = StringBuilder()
        while (pos < d.size) {
            val len = d[pos].toInt() and 0xFF
            if (len == 0) break
            if (len > 63 || pos + 1 + len > d.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(d, pos + 1, len, Charsets.US_ASCII))
            pos += len + 1
        }
        return sb.toString().lowercase()
    }

    private fun isBlocked(name: String): Boolean {
        val hit = Prefs(this).domains.any { name == it || name.endsWith(".$it") }
        return hit && Scheduler.isBlocking(this)
    }

    private fun nxdomain(d: ByteArray): ByteArray {
        var pos = 12
        while (d[pos].toInt() != 0) pos += (d[pos].toInt() and 0xFF) + 1
        val r = d.copyOf(pos + 5)
        r[2] = 0x81.toByte(); r[3] = 0x83.toByte()
        for (i in 6..11) r[i] = 0
        return r
    }

    private fun forward(d: ByteArray): ByteArray? {
        val s = DatagramSocket()
        try {
            protect(s)
            s.soTimeout = 4000
            s.send(DatagramPacket(d, d.size, InetAddress.getByName("1.1.1.1"), 53))
            val b = ByteArray(4096)
            val p = DatagramPacket(b, b.size)
            s.receive(p)
            return b.copyOf(p.length)
        } finally { s.close() }
    }

    private fun write(out: FileOutputStream, srcIp: ByteArray, dstIp: ByteArray, sport: Int, dport: Int, dns: ByteArray) {
        val total = 28 + dns.size
        val b = ByteArray(total)
        b[0] = 0x45; b[2] = (total shr 8).toByte(); b[3] = total.toByte()
        b[6] = 0x40; b[8] = 64; b[9] = 17
        System.arraycopy(srcIp, 0, b, 12, 4)
        System.arraycopy(dstIp, 0, b, 16, 4)
        var sum = 0
        for (i in 0 until 20 step 2) sum += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
        while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        val ck = sum.inv() and 0xFFFF
        b[10] = (ck shr 8).toByte(); b[11] = ck.toByte()
        b[20] = (sport shr 8).toByte(); b[21] = sport.toByte()
        b[22] = (dport shr 8).toByte(); b[23] = dport.toByte()
        val ul = 8 + dns.size
        b[24] = (ul shr 8).toByte(); b[25] = ul.toByte()
        System.arraycopy(dns, 0, b, 28, dns.size)
        synchronized(out) { out.write(b) }
    }

    override fun onDestroy() {
        running = false
        try { tun?.close() } catch (e: Exception) { }
        pool.shutdownNow()
        super.onDestroy()
    }
}
