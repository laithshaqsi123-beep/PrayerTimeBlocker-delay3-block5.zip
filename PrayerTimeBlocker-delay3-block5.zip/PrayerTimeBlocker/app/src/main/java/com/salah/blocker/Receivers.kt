package com.salah.blocker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val pr = goAsync()
        Thread { try { Scheduler.tick(ctx.applicationContext) } finally { pr.finish() } }.start()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val pr = goAsync()
        Thread { try { Scheduler.tick(ctx.applicationContext) } finally { pr.finish() } }.start()
    }
}
