package com.salah.blocker

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class BlockerService : AccessibilityService() {
    companion object { @Volatile var instance: BlockerService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        check(e.packageName?.toString())
    }

    /** يُستدعى لحظة بدء الصلاة إذا كان تطبيق محجوب مفتوحًا أصلًا. */
    fun checkNow() { check(rootInActiveWindow?.packageName?.toString()) }

    private fun check(pkg: String?) {
        if (pkg == null || pkg == packageName) return
        if (pkg !in Prefs(this).blockedApps || !Scheduler.isBlocking(this)) return
        startActivity(
            Intent(this, PrayerActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
    }
}
