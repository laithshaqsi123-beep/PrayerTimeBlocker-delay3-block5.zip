package com.salah.blocker

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.TimeZone

object PrayerRepo {
    val NAMES = listOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء")
    private val KEYS = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
    private val F = DateTimeFormatter.ofPattern("dd-MM-yyyy")

    /** مواقيت يوم معين من الذاكرة المحلية مع تطبيق فروق الدقائق، أو null إن لم تتوفر. */
    fun timesFor(ctx: Context, d: LocalDate): List<LocalTime>? {
        val p = Prefs(ctx)
        val s = p.times().optString(d.format(F), "")
        val parts = s.split(",")
        if (parts.size != 5) return null
        return try {
            parts.mapIndexed { i, t -> LocalTime.parse(t).plusMinutes(p.offset(i).toLong()) }
        } catch (e: Exception) { null }
    }

    /** يجلب الشهر من Aladhan (زاوية الفجر والعشاء 18° المعتمدة في عُمان؛ يمكن تعديلها بالفروق اليدوية). */
    private fun fetchMonth(ctx: Context, ym: YearMonth): Boolean = try {
        val p = Prefs(ctx)
        val (lat, lng) = p.latLng()
        val url = "https://api.aladhan.com/v1/calendar?latitude=$lat&longitude=$lng" +
            "&method=99&methodSettings=18,null,18&month=${ym.monthValue}&year=${ym.year}" +
            "&timezonestring=${TimeZone.getDefault().id}"
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        val body = c.inputStream.bufferedReader().use { it.readText() }
        val data = JSONObject(body).getJSONArray("data")
        val store = p.times()
        for (i in 0 until data.length()) {
            val o = data.getJSONObject(i)
            val t = o.getJSONObject("timings")
            val key = o.getJSONObject("date").getJSONObject("gregorian").getString("date")
            store.put(key, KEYS.joinToString(",") { t.getString(it).substring(0, 5) })
        }
        p.putTimes(store)
        true
    } catch (e: Exception) { false }

    /** يحدّث المواقيت مرة يوميًا أو عند نقصها. يُستدعى من خيط خلفي فقط. */
    fun ensure(ctx: Context, force: Boolean = false): Boolean {
        val p = Prefs(ctx)
        val sig = p.latLng().toString()
        if (p.sig != sig) { p.putTimes(JSONObject()); p.sig = sig; p.lastFetchDay = "" }
        val today = LocalDate.now()
        val missing = timesFor(ctx, today.plusDays(2)) == null
        if (force || missing || p.lastFetchDay != today.toString()) {
            val ym = YearMonth.from(today)
            val a = fetchMonth(ctx, ym)
            if (a) { fetchMonth(ctx, ym.plusMonths(1)); p.lastFetchDay = today.toString() }
        }
        return timesFor(ctx, today) != null
    }
}
