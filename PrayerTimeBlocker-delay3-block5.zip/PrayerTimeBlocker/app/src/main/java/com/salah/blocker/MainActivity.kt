package com.salah.blocker

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.location.Criteria
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Duration
import java.time.LocalDate
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { Root() }
            }
        }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme())
        darkColorScheme(primary = Color(0xFF5FD3A6), onPrimary = Color(0xFF00382A))
    else lightColorScheme(primary = Color(0xFF1B7F5C))
    MaterialTheme(colorScheme = scheme, content = content)
}

private val TF = DateTimeFormatter.ofPattern("HH:mm")
private fun fmt(d: Duration): String {
    val s = d.seconds.coerceAtLeast(0)
    return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
}

fun isAccessibilityOn(ctx: Context): Boolean {
    val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    return s.contains(ctx.packageName + "/") && s.contains("BlockerService")
}

@Composable
fun Root() {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(bottomBar = {
        NavigationBar {
            listOf("🕌" to "الرئيسية", "📱" to "التطبيقات", "⚙️" to "الإعدادات").forEachIndexed { i, (e, l) ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(e) }, label = { Text(l) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) { 0 -> Home(); 1 -> AppsScreen(); else -> SettingsScreen() }
        }
    }
}

@Composable
fun PermRow(title: String, desc: String, ok: Boolean, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text((if (ok) "✅ " else "⚠️ ") + title, fontWeight = FontWeight.Bold)
            if (!ok) {
                Text(desc, Modifier.padding(vertical = 6.dp), style = MaterialTheme.typography.bodySmall)
                Button(onClick = onClick) { Text("تفعيل") }
            }
        }
    }
}

@Composable
fun Home() {
    val ctx = LocalContext.current
    val p = remember { Prefs(ctx) }
    var enabled by remember { mutableStateOf(p.enabled) }
    var tick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) { PrayerRepo.ensure(ctx) }
        Scheduler.reschedule(ctx)
        while (true) { tick = System.currentTimeMillis(); delay(1000) }
    }
    val vpnLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { Scheduler.ensureVpn(ctx) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    @Suppress("UNUSED_VARIABLE") val t = tick
    val now = ZonedDateTime.now()
    val cur = Scheduler.current(ctx)
    val next = Scheduler.next(ctx)
    val today = PrayerRepo.timesFor(ctx, LocalDate.now())

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (cur != null) {
                    Text("بدأ الحجب بعد الأذان بثلاث دقائق – صلاة ${PrayerRepo.NAMES[cur.idx]}")
                    Text(fmt(Duration.between(now, cur.end)), fontSize = 44.sp, color = MaterialTheme.colorScheme.primary)
                    Text("المتبقي حتى فتح التطبيقات")
                } else if (next != null) {
                    Text("الحجب القادم بعد الأذان بـ 3 دقائق")
                    Text(PrayerRepo.NAMES[next.idx], fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Text(fmt(Duration.between(now, next.start)), fontSize = 44.sp, color = MaterialTheme.colorScheme.primary)
                } else Text("لا توجد مواقيت محفوظة بعد. اتصل بالإنترنت لتحميلها.")
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("نظام الحجب", fontWeight = FontWeight.Bold)
                    Text(if (cur != null) "الحجب نشط الآن" else if (enabled) "مفعّل – بانتظار وقت الصلاة" else "غير مفعّل")
                }
                Switch(checked = enabled, onCheckedChange = {
                    enabled = it; p.enabled = it
                    Scheduler.reschedule(ctx)
                    if (it) Scheduler.ensureVpn(ctx) else ctx.stopService(Intent(ctx, DnsVpnService::class.java))
                })
            }
        }
        PermRow("خدمة إمكانية الوصول (حجب التطبيقات)",
            "تُستخدم فقط لمعرفة اسم التطبيق المفتوح وعرض شاشة الصلاة. فعّل «صلاة – وقت العبادة» من القائمة التي ستظهر.",
            isAccessibilityOn(ctx)) { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        PermRow("خدمة VPN المحلية (حجب المواقع)",
            "لا تُرسل بياناتك لأي خادم؛ تعترض طلبات أسماء النطاقات فقط وتحجب مواقع التواصل وقت الصلاة. سيطلب النظام موافقتك.",
            VpnService.prepare(ctx) == null) {
            val i = VpnService.prepare(ctx)
            if (i != null) vpnLauncher.launch(i) else Scheduler.ensureVpn(ctx)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            PermRow("الإشعارات", "مطلوبة لإظهار إشعار خدمة VPN الدائم.",
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("مواقيت اليوم", fontWeight = FontWeight.Bold)
                for (i in 0..4) {
                    val isNext = next != null && next.idx == i && next.start.toLocalDate() == LocalDate.now()
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(PrayerRepo.NAMES[i], fontWeight = if (isNext) FontWeight.Bold else FontWeight.Normal,
                            color = if (isNext) MaterialTheme.colorScheme.primary else Color.Unspecified)
                        Text(today?.get(i)?.format(TF) ?: "--:--")
                    }
                }
            }
        }
    }
}

@Composable
fun AppsScreen() {
    val ctx = LocalContext.current
    val p = remember { Prefs(ctx) }
    var blocked by remember { mutableStateOf(p.blockedApps) }
    var apps by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var q by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            val saved = p.blockedApps
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
                .distinctBy { it.first }.filter { it.first != ctx.packageName }
                .sortedWith(compareByDescending<Pair<String, String>> { it.first in saved }.thenBy { it.second.lowercase() })
        }
    }
    fun toggle(pkg: String) {
        blocked = if (pkg in blocked) blocked - pkg else blocked + pkg
        p.blockedApps = blocked
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(12.dp), label = { Text("بحث في التطبيقات") }, singleLine = true)
        LazyColumn {
            items(apps.filter { it.second.contains(q, true) }, key = { it.first }) { (pkg, label) ->
                Row(Modifier.fillMaxWidth().clickable { toggle(pkg) }.padding(horizontal = 16.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(pkg in blocked, { toggle(pkg) })
                    Text(label)
                }
            }
        }
    }
}

@Composable
fun Stepper(label: String, value: Int, unit: String, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        OutlinedButton({ onChange(value - 1) }) { Text("−") }
        Text("$value $unit", Modifier.padding(horizontal = 8.dp))
        OutlinedButton({ onChange(value + 1) }) { Text("+") }
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val p = remember { Prefs(ctx) }
    val scope = rememberCoroutineScope()
    var cityIdx by remember { mutableIntStateOf(p.cityIdx) }
    var menu by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var dur by remember { mutableIntStateOf(p.duration) }
    val offs = remember { mutableStateListOf(*Array(5) { p.offset(it) }) }
    var domains by remember { mutableStateOf(p.domains) }
    var newDomain by remember { mutableStateOf("") }

    fun refresh(force: Boolean) {
        msg = "جارٍ تحديث المواقيت…"
        scope.launch {
            val ok = withContext(Dispatchers.IO) { PrayerRepo.ensure(ctx, force) }
            Scheduler.reschedule(ctx)
            msg = if (ok) "تم تحديث المواقيت ✅" else "تعذر التحديث؛ تُستخدم المواقيت المحفوظة"
        }
    }

    fun saveDetectedLocation(loc: Location?) {
        if (loc != null) {
            p.gpsLat = loc.latitude
            p.gpsLng = loc.longitude
            p.cityIdx = -1
            cityIdx = -1
            refresh(true)
        } else {
            msg = "تعذر الحصول على موقع حالي. تأكد من تشغيل خدمة الموقع ثم حاول مرة أخرى."
        }
    }

    val locLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        val allowed = grants[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (allowed) {
            val lm = ctx.getSystemService(LocationManager::class.java)
            try {
                val provider = lm.getBestProvider(Criteria(), true)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && provider != null) {
                    msg = "جارٍ تحديد موقعك الحالي…"
                    lm.getCurrentLocation(provider, null, ctx.mainExecutor) { location ->
                        if (location != null) {
                            saveDetectedLocation(location)
                        } else {
                            // لا نستخدم موقعاً مخزناً إلا إذا كان حديثاً جداً (دقيقتان كحد أقصى).
                            val nowNanos = android.os.SystemClock.elapsedRealtimeNanos()
                            val candidates = mutableListOf<Location>()
                            for (name in listOf("gps", "network", "passive")) {
                                try {
                                    lm.getLastKnownLocation(name)?.let { candidates.add(it) }
                                } catch (_: SecurityException) { }
                            }
                            val fresh = candidates
                                .filter { nowNanos >= it.elapsedRealtimeNanos &&
                                    nowNanos - it.elapsedRealtimeNanos <= 120_000_000_000L }
                                .maxByOrNull { it.elapsedRealtimeNanos }
                            saveDetectedLocation(fresh)
                        }
                    }
                } else {
                    // في إصدارات Android الأقدم: نرفض أي موقع مخزّن أقدم من دقيقتين.
                    val nowNanos = android.os.SystemClock.elapsedRealtimeNanos()
                    val candidates = mutableListOf<Location>()
                    for (name in listOf("gps", "network", "passive")) {
                        try {
                            lm.getLastKnownLocation(name)?.let { candidates.add(it) }
                        } catch (_: SecurityException) { }
                    }
                    val fresh = candidates
                        .filter { nowNanos >= it.elapsedRealtimeNanos &&
                            nowNanos - it.elapsedRealtimeNanos <= 120_000_000_000L }
                        .maxByOrNull { it.elapsedRealtimeNanos }
                    saveDetectedLocation(fresh)
                }
            } catch (_: SecurityException) {
                msg = "لم يتم منح صلاحية الموقع. اختر السماح بالموقع أثناء استخدام التطبيق."
            }
        } else {
            msg = "نحتاج صلاحية الموقع لتحديد مواقيت الصلاة في مكانك الحالي."
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("المدينة", fontWeight = FontWeight.Bold)
        Box {
            OutlinedButton({ menu = true }) {
                Text(CITIES.getOrNull(cityIdx)?.name ?: "📍 الموقع الحالي")
            }
            DropdownMenu(menu, { menu = false }) {
                CITIES.forEachIndexed { i, c ->
                    DropdownMenuItem({ Text(c.name) }, { cityIdx = i; p.cityIdx = i; menu = false; refresh(false) })
                }
                DropdownMenuItem({ Text("📍 الموقع الحالي") }, {
                    menu = false; locLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                })
            }
        }
        Button({ refresh(true) }) { Text("تحديث المواقيت الآن") }
        if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall)

        HorizontalDivider()
        Text("يبدأ الحجب بعد الأذان بـ 3 دقائق لكل صلاة", fontWeight = FontWeight.Bold)
        Text("مدة الحجب", fontWeight = FontWeight.Bold)
        Stepper("بعد دخول وقت الصلاة", dur, "دقيقة") { dur = it.coerceIn(5, 30); p.duration = dur; Scheduler.reschedule(ctx) }

        HorizontalDivider()
        Text("تعديل المواقيت بالدقائق (مطابقة تقويم وزارة الأوقاف)", fontWeight = FontWeight.Bold)
        for (i in 0..4) Stepper(PrayerRepo.NAMES[i], offs[i], "د") {
            offs[i] = it.coerceIn(-30, 30); p.setOffset(i, offs[i]); Scheduler.reschedule(ctx)
        }

        HorizontalDivider()
        Text("المواقع المحجوبة", fontWeight = FontWeight.Bold)
        domains.sorted().forEach { d ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(d, Modifier.weight(1f))
                TextButton({ domains = domains - d; p.domains = domains }) { Text("✕") }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(newDomain, { newDomain = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("example.com") })
            Spacer(Modifier.width(8.dp))
            Button({
                val d = newDomain.trim().lowercase().removePrefix("www.")
                if (d.contains('.')) { domains = domains + d; p.domains = domains; newDomain = "" }
            }) { Text("إضافة") }
        }
        Text(
            "ملاحظة: إذا فعّلت «DNS الخاص» (Private DNS) في إعدادات الشبكة أو «DNS الآمن» في المتصفح فقد يتجاوز حجب المواقع.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
